package com.ocado.basket.model;

public record DeliveryMethod(String name) {}
