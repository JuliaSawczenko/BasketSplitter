package com.ocado.basket.model;

public record Product(String name) {}
